# AplikasiSPP-CI4

Aplikasi ini dikembangan dengan menggunakan :
PHP Versi 7.2.24
PHP Framework Codeigniter 4.0.5
MySQL 14.14

Dikembangkan sebagai project Contoh Uji Kompetensi Program Keahlian Rekayasa Perangkat Lunak SMK Negeri 2 Kuningan Tahun 2020.

Petunjuk Instalasi
==================
1.  Rename file env menjadi .env (titik env)
2.  Ubah bagian 

    app.baseURL = ''

    Menjadi alamat URL aplikasi anda
3.  Ubah environment menjadi production jika akan di onlinkan
4.  Ubah seting database di bagian Database

Petunjuk Penggunaan 
====================
1.  login siswa :
    http://hostname

2.  Login Petugas admin & Non Admin
    http://hostname/petugas

3.  User admin      : adminSPP
    password admin  : 123

Untuk artikel dan dokumentasi lainnya bisa dibaca di http://ozs.web.id

Untuk video tutorial silahkan kunjungi official channel youtube
https://youtube.com/c/PojokProgrammer
